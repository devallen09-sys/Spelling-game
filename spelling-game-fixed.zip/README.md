# Spelling Game (Fixed)

This is the repaired version of your spelling game for GitHub Pages.

## How to use
1. Upload this repo folder contents (index.html) to your GitHub repository.
2. Push to `main` branch.
3. Enable GitHub Pages in repo settings (if not already).
4. Visit `https://<your-username>.github.io/<repo-name>/` to play the game.

